
import VideoContainer from "./Videcontainer";


const MainContainer=()=>{
  
    return (

      <div className="col-span-10">
          <VideoContainer/>
        </div>
          
    )
}
export default MainContainer;