import { useDispatch } from "react-redux";
import { useParams } from "react-router-dom";
import { useEffect} from "react";
import { closemenu } from "../utils/toggle";

const Mainvideo = () => {
  const {id}=useParams()

  return (
    <div className="p-2">
      
        <iframe
          width="885"
          height="445"
          frameBorder="0"
          src={`https://www.youtube.com/embed/${id}`}
          title="YouTube Video Player"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        ></iframe>
    </div>
  );
};

export default Mainvideo;
